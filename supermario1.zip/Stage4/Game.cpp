#include <sgg/graphics.h>

#include "Enemy.h"
#include "Player.h"

bool Game::checkCollision() {

	player->

	return false;

}


void Game::drawStarsScreen() {

	graphics::Brush br;
	char info[40];
	sprintf_s(info, "Press ENTER to start");
	graphics::drawText(CANVAS_WIDTH / 2, CANVAS_HEIGHT / 2, 30, info, br);

	graphics::MouseState ms;
	graphics::getMouseState(ms);

	graphics::drawDisk(window2canvasX(ms.cur_pos_x), window2canvasY(ms.cur_pos_y), 10, br);


}

void Game::drawLevelScreen() {

	graphics::Brush br;
	br.texture = std::string(ASSET_PATH) + "///////";
	br.outline_opacity = 0.0f;


	graphics::drawRect(CANVAS_WIDTH / 2, CANVAS_HEIGHT / 2, CANVAS_WIDTH, CANVAS_HEIGHT, br);

	if (player)
		player->draw();
	if (meteorite)
		meteorite->draw();

	if
}

void Game::updateStartScreen() {

	if (graphics::getKeyState(graphics::SCANCODE_RETURN))
		status = STATUS_PLAYING;

	graphics::MouseState ms;
	graphics::getMouseState(ms);

	if (ms.button_left_pressed) {
		status = STATUS_PLAYING;
	}

}

void Game::updateLevelScreen() {

	if (!player_initialized && graphics::getGlobalTime() > 1000) {

		player = new Player(*this);

	}

}