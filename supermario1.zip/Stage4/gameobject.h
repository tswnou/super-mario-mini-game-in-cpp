#pragma once
#include <string>
#include "gamestate.h"
#include "util.h"

class GameObject 
{
	static int m_next_id;
	//
	const class Game& game;
	//
	
protected:
	class GameState* m_state;
	std::string m_name;
	int m_id = 0;
	bool m_active = true;

public:
	GameObject(const std::string& name = "");
	virtual void update(float dt) {}
	virtual void init() {}
	virtual void draw() {}
	virtual ~GameObject() {}
	bool isActive() { return m_active; }
	void setActive(bool a) { m_active = a; }

	//
	GameObject(const class Game& mygame);
	virtual void update() = 0;
	virtual void draw() = 0;
	virtual void init() = 0;
	//
};

//
class Colliadable {

public:
	Virtual Disk getCollisionHull() = 0;

};