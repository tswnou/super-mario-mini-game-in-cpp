#pragma once

#include "Enemy.h"
#include "Player.h"


class Game
{

    Player* player = nullptr;
    bool player_initialized = false;
    bool debug_mode = false;
    Enemy* meteorite = nullptr;
    void spawnMeteorite();
    void checkMeteorite();

    bool checkCollision();

public:
   
    void setDebugMode(bool d) { debug_mode = d; }
    bool getDebugMode() { return debug_mode; }
    void update();
    void draw();
    void init();
    Game();
    ~Game();

};
