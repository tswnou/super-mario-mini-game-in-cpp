#pragma once
#include <random>

#define SETCOLOR(c, r, g, b) {c[0]=r; c[1]=g; c[2]=b;}

float rand0to1() {

	return rand() / (float)RAND_MAX;

}

struct Disk {

	float cx, cy;
	float radius;

};
